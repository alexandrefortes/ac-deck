-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: mpg123
Binary: mpg123, libmpg123-0t64, libout123-0t64, libsyn123-0t64, libmpg123-dev
Architecture: any
Version: 1.32.10-1+deb13u1
Maintainer: Debian Multimedia Maintainers <debian-multimedia@lists.debian.org>
Uploaders:  Reinhard Tartler <siretart@tauware.de>, Miguel A. Colón Vélez <debian.micove@gmail.com>, Sebastian Ramacher <sramacher@debian.org>
Homepage: http://mpg123.org/
Standards-Version: 4.7.0
Vcs-Browser: https://salsa.debian.org/multimedia-team/mpg123
Vcs-Git: https://salsa.debian.org/multimedia-team/mpg123.git
Build-Depends: dpkg-dev (>= 1.22.5), debhelper-compat (= 13), libasound2-dev [linux-any], libaudio-dev, libjack-dev, libltdl-dev, libopenal-dev, libpulse-dev [!hurd-any], pkgconf, portaudio19-dev
Package-List:
 libmpg123-0t64 deb libs optional arch=any
 libmpg123-dev deb libdevel optional arch=any
 libout123-0t64 deb libs optional arch=any
 libsyn123-0t64 deb libs optional arch=any
 mpg123 deb sound optional arch=any
Checksums-Sha1:
 e069646e5490eda8c25f304164309109ccaf980e 930140 mpg123_1.32.10.orig.tar.xz
 c0e0c51a2c159c16fec2b6ef3a6a5fad3350d413 28336 mpg123_1.32.10-1+deb13u1.debian.tar.xz
Checksums-Sha256:
 98867a796fa1eeb161847d211734d585ff61c56712fbc333de416fea7b59de29 930140 mpg123_1.32.10.orig.tar.xz
 cba7a4fd6b2f73b99abaf85eeee96964b31b9695aeed77e6b8e8e50e219ef19f 28336 mpg123_1.32.10-1+deb13u1.debian.tar.xz
Files:
 a7b2a5a8b6e68fa6b821369ea1a7958d 930140 mpg123_1.32.10.orig.tar.xz
 272b5d7e751313768cceb1d717e8a12c 28336 mpg123_1.32.10-1+deb13u1.debian.tar.xz


-----BEGIN PGP SIGNATURE-----

wr0EARYKAG8FgmmomLEJECGTazZgD82JRxQAAAAAAB4AIHNhbHRAbm90YXRpb25z
LnNlcXVvaWEtcGdwLm9yZ2/eArRIN3CPl+08AEe+uhQ0tbJkWSGBPTuJTamMrw6W
FiEEQmJ+hB2ZZ9qD4fqQIZNrNmAPzYkAAN74AQDjOt4DM5U/kod2N99UlISNYmq0
XTJj6VbE1h9GKY4WagD+J2udMQ5BmaxG9l4EEQn6OVFTYApAzqJLT/7fzVNVIQ8=
=7YWm
-----END PGP SIGNATURE-----
