-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: libsndfile
Binary: libsndfile1-dev, libsndfile1, sndfile-programs
Architecture: any
Version: 1.2.2-2+deb13u1
Maintainer: Debian Multimedia Maintainers <debian-multimedia@lists.debian.org>
Uploaders:  IOhannes m zmölnig (Debian/GNU) <umlaeute@debian.org>, Fabian Greffrath <fabian@debian.org>,
Homepage: https://libsndfile.github.io/libsndfile/
Standards-Version: 4.7.0
Vcs-Browser: https://salsa.debian.org/multimedia-team/libsndfile
Vcs-Git: https://salsa.debian.org/multimedia-team/libsndfile.git
Testsuite: autopkgtest
Testsuite-Triggers: build-essential, pkg-config, python3
Build-Depends: autogen, debhelper-compat (= 13), libasound2-dev [linux-any], libflac-dev, libmp3lame-dev <!pkg.libsndfile.nompeg3>, libmpg123-dev <!pkg.libsndfile.nompeg3>, libogg-dev, libopus-dev, libspeex-dev, libsqlite3-dev <!nocheck>, libvorbis-dev, pkgconf, python3:any
Package-List:
 libsndfile1 deb libs optional arch=any
 libsndfile1-dev deb libdevel optional arch=any
 sndfile-programs deb utils optional arch=any
Checksums-Sha1:
 28acc1c19b06c18f38f906d7efef404b2078a19a 684875 libsndfile_1.2.2.orig.tar.gz
 a969641907c68a037bd22b61ec54b10454b2238e 29472 libsndfile_1.2.2-2+deb13u1.debian.tar.xz
Checksums-Sha256:
 ffe12ef8add3eaca876f04087734e6e8e029350082f3251f565fa9da55b52121 684875 libsndfile_1.2.2.orig.tar.gz
 2549d7a791ca177213918fbcf9c9e39c5734a2e18782341b44d71e4b39365296 29472 libsndfile_1.2.2-2+deb13u1.debian.tar.xz
Files:
 9fe64f68622e54badb5d4bf658fc940a 684875 libsndfile_1.2.2.orig.tar.gz
 269c923b15aa875c39f4baa1874fd919 29472 libsndfile_1.2.2-2+deb13u1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEtuYvPRKsOElcDakFEMKTtsN8TjYFAmmrC4IACgkQEMKTtsN8
TjZgSBAAqM6lB9QRv+l7wO+/yIHVgF85L32L40wK8FNDajN1Pi8XM77KV0a17dFD
muLV6S8T951vQQG7M6c4Q69if9DdcciBLfHSLZRpmcxGRQdCmFP09xHtnGZ5aP6d
W5Q4+qb0JVQGlSNHGGVK3x9SjWTssVI8UbzqCPzwTjTk68SHEdIhtxQ0p6pd+r5o
ziHAfTKCjvL1Hn1Tv2MmTj7QtwhZss2i4Gp5P/rYZLYzaf6dNWM/VIMcU4ZtdKCW
1cir1x8u3GiURvwUmLfh8KiV/beHKkDsa/RIYExznjqejdU72K0Tzxp7MFbEFCcU
qpXqx3yKuNUUqmDeVNAaj0h5kEMiADhMLoWbz1IDc/PwNnRuBZJJX6SiaSPz0R19
5atbVKyULcVs0wxIMljbORF/sphepUP+228ap4KzY+UEHqlLIlftl8NjcAdygdeM
bYVWV+SuxypzHxjXp7F5dbYzQds9b34ZJ2XrshdyZ+hgQDwDq4BlFfEAZFBP5Xmn
0KEjYVITq4g2628JKi9k5Ux11PfvIGlSbKEkTadCq0WU1rSIAYtWB7/9I1/Q6W8t
YqjKiuaXD6T1wquxrogKgShPE3TwVvG9iWa3Amp5HqIWUor5GxMywHrRz/apYqWO
h6x1DPHvG1AorLcyufxhqTTP/uc/3zNfOU+aGmHdUYyB/4phlMY=
=XguI
-----END PGP SIGNATURE-----
