ac-deck: corresponding sources of bundled LGPL libraries

This companion source distribution preserves the original Debian source
descriptors and every file declared by their SHA-256 tables, including upstream
tarballs, Debian patches/build rules and any declared upstream signatures.
No source archive has been unpacked, rewritten or relicensed.

dependency-source-inventory.json maps the exact source package revisions to
the shared-library hashes in ac-deck community-preview-002. Binary-only Debian
rebuild suffixes (+b1, +b3, +b5) do not change the source package revision.

These third-party sources keep their original licenses. The first-party
ac-deck PolyForm license does not replace or restrict their license grants.
License summaries concern the bundled libraries, not every file in the full
upstream source distributions; consult each preserved source and its Debian
copyright notice for file-specific terms.

To reconstruct a Debian source tree, install standard Debian build tools and
run dpkg-source -x PACKAGE_VERSION.dsc in its package directory. The descriptor
and its referenced files must remain together. Debian packaging includes build
rules and dependency declarations. No rebuild is claimed or required to access
these original sources. Shared libraries in ac-deck remain separate replaceable
files; this source companion does not change the application license or grant
an additional application-license exception.

All downloads used the Debian HTTPS mirror recorded per file. File sizes and
SHA-256 values were verified against each retained descriptor. Uploader
OpenPGP signatures are retained but have not been independently authenticated.

Distribute this complete companion alongside the matching ac-deck binary,
with its inventory and all original notices. It provides copies directly;
access to these sources does not depend on future upstream availability.
